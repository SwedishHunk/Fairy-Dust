(() => {
  "use strict";
  function normalizeVs(value) {
    const JOINERS_RX = window.DPT_CONSTANTS?.RX?.JOINERS_RX;
    if (!JOINERS_RX) throw new Error("[DPT] JOINERS_RX saknas.");
    return String(value || "")
      .replace(/\b(vs|versus)\b/gi, "vs.")
      .replace(/\s{2,}/g, " ")
      .trim();
  }
  window.normalizeVs = normalizeVs;
})();
