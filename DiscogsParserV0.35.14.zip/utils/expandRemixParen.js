(() => {
  "use strict";

  function expandRemixParenLeft(value, steps = 1) {
    if (
      !window.DPT_CONSTANTS?.JOINERS ||
      !window.DPT_CONSTANTS?.RX?.JOINERS_RX
    ) {
      throw new Error(
        "[DPT] DPT_CONSTANTS.JOINERS / JOINERS_RX saknas (laddordning?)."
      );
    }
    let x = String(value || "");
    if (!/\(\s*(?:Remix|Mix)\s*\)/i.test(x)) return x;

    const JOINERS = window.DPT_CONSTANTS.JOINERS;

    const words = x.split(/\s+/);
    const remixIdx = words.findIndex(
      (w) =>
        /\(\s*(?:Remix|Mix)\s*\)/i.test(w) || /\(\s*(?:Remix|Mix)\b/i.test(w)
    );
    if (remixIdx === -1) return x;

    const before = words.slice(0, remixIdx);
    const after = words.slice(remixIdx);

    let moveCount = 0;
    let i = before.length - 1;
    const targetSteps = Math.max(1, steps | 0);

    while (i >= 0 && moveCount < targetSteps) {
      const raw = before[i];
      const plain = raw.replace(/[()]/g, "");
      if (JOINERS.includes(plain.toLowerCase())) {
        i--;
        continue;
      } // hoppa över joiners
      moveCount++;
      i--;
    }

    const cut = Math.max(0, i + 1);
    const leftPart = before.slice(0, cut).join(" ");
    const movedPart = before.slice(cut).join(" ");
    const rightPart = after.join(" ").replace(/^\(\s*(Remix|Mix)\s*\)/i, "$1");

    return `${leftPart}${leftPart ? " " : ""}(${movedPart} ${rightPart})`
      .replace(/\s{2,}/g, " ")
      .trim();
  }

  window.expandRemixParenLeft = expandRemixParenLeft;
})();
