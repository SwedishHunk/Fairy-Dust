(() => {
  // Delnings-tecken (olika “streck”) – samma klass som i init.js
  const DASH_CLASS = "[\\-–—‒−‐-]";

  // Om titeln (av misstag) börjar med artisten + streck → skala bort prefixet
  function stripLeadingArtistPrefix(title, artist) {
    if (!title || !artist) return title;
    const a = window.cleanArtistName ? cleanArtistName(artist) : (artist || "").trim();
    const rx = new RegExp(
      "^" +
        escapeRegExp(a) +
        "(?:\\s*\\(\\d+\\)\\s*|\\*+\\s*)?" + // valfritt (3) eller * efter artistnamnet
        "\\s*" +                             // ev. blank före streck
        DASH_CLASS +
        "\\s*",                              // ev. blank efter streck
      "i"
    );
    return title.replace(rx, "").trim();
  }

  window.stripLeadingArtistPrefix = stripLeadingArtistPrefix;
})();
