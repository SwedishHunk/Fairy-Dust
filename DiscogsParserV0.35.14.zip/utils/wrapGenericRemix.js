(() => {
  function wrapGenericRemix(s) {
    if (!s) return s;
    var x = String(s);

    // Redan parentes runt Remix/Mix? -> normalisera bara whitespace
    if (/\(\s*(Remix|Mix)\s*\)/i.test(x)) {
      return x.replace(/\(\s*(Remix|Mix)\s*\)/gi, "($1)");
    }

    // Sätt parenteser runt fristående Remix/Mix även om det följs av
    // (Part ...), Pt/Part, Vol, bindestreck eller slut på sträng.
    // (Lookahead används; funkar i CEF/Chrome i MM5.)
    x = x.replace(
      /\b(Remix|Mix)\b(?=\s*(?:$|\(|-|\b(?:pt\.?|part|vol\.?)\b))/gi,
      "($1)"
    );

    // Om något glapp skapats: strama åt lite
    x = x.replace(/\(\s*(Remix|Mix)\s*\)/gi, "($1)");
    x = x.replace(/\s{2,}/g, " ").trim();
    return x;
  }

  window.wrapGenericRemix = wrapGenericRemix;
})();
