(() => {
  "use strict";
  function normalizeFeat(value) {
    const JOINERS_RX = window.DPT_CONSTANTS?.RX?.JOINERS_RX;
    if (!JOINERS_RX) throw new Error("[DPT] JOINERS_RX saknas.");
    return String(value || "")
      .replace(/\b(ft|feat|featuring)\b/gi, "feat.")
      .replace(/\s{2,}/g, " ")
      .trim();
  }
  window.normalizeFeat = normalizeFeat;
})();
