(() => {
  "use strict";
  const JOINERS = Object.freeze([
    "vs.",
    "vs",
    "&",
    "and",
    "feat.",
    "feat",
    "ft.",
    "ft",
    "with",
  ]);

  const JOINERS_RX = new RegExp(
    "\\b(?:" +
      ["vs\\.?", "&", "and", "feat\\.?", "ft\\.?", "with"].join("|") +
      ")\\b",
    "i"
  );

  if (!window.DPT_CONSTANTS) window.DPT_CONSTANTS = {};
  Object.assign(window.DPT_CONSTANTS, {
    JOINERS,
    RX: Object.freeze({ JOINERS_RX }),
  });
})();
